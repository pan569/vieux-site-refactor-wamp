<?php
namespace motif\modele;

use systeme\objets\Item;

class personne  extends Item
{
    
    public $fichierIni;
    public $personne;
    
    public function __construct(string $fichierIni, string $personne)
    {
        
        self::getDictionaire()->clearDefinition();
        $this->fichierIni = $fichierIni;
        $this->personne = $personne;
        
        $this->donnees['nom']=NULL;
        $this->donnees['adresse']=NULL;
        $this->donnees['telephone']=NULL;
        $this->donnees['email']=NULL;
        $this->donnees['www']=NULL;
        
        $this->LireXmlElementAttribut($this->fichierIni, 'Credits', $this->personne);
        
        return $this;
    }
    
    public function SauvegardeElement()
    {
        
        $this->EcrireXmlElementAttribut($this->fichierIni, 'Credits', $this->personne);
        
    }
    
}

