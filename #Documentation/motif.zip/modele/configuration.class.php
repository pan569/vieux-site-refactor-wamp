<?php
namespace motif\modele;

use systeme\objets\Item;

class Configuration  extends Item
{
    public $fichierIni;
    
    public function __construct(string $fichierIni)
    {
                
        self::getDictionaire()->clearDefinition();
        $this->fichierIni = $fichierIni;
       
        
        $this->donnees['SiteNom']=NULL;
        $this->donnees['SiteDescriptif']=NULL;
        $this->donnees['SiteThemeDossier']=NULL;
        $this->donnees['SiteThemeNom']=NULL;
        $this->donnees['SiteJavaScriptDossier']=NULL;
        $this->donnees['DataBaseServeur']=NULL;
        $this->donnees['DataBaseUtilisateur']=NULL;
        $this->donnees['DataBaseMdP']=NULL;
        $this->donnees['DataBaseNon']=NULL;
        $this->donnees['SiteCopyright']=NULL;
        
        $this->LireXmlElement($this->fichierIni, 'Configuration');
        
        foreach (array_keys($this->donnees) as $clé)
        {
            $this->donnees[$clé]=str_replace("|" , DIRECTORY_SEPARATOR , $this->donnees[$clé] );
        }
        
        return $this;
    }
    
    public function SauvegardeElement()
    {        
        $this->EcrireXmlElement($this->fichierIni, 'Configuration');        
    }
    
}

