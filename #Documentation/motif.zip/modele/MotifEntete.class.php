<?php
namespace motif\modele;

use systeme\objets\Item;

class MotifEntete  extends Item
{
    
    public $fichierIni;
    
    public function __construct(string $fichierIni)
    {
        
        self::getDictionaire()->clearDefinition();
        $this->fichierIni = $fichierIni;
        
        $this->donnees['auteur']=NULL;
        $this->donnees['description']=NULL;
        $this->donnees['motsCles']=NULL;
        $this->donnees['editeur']=NULL;
        $this->donnees['titre']=NULL;
        $this->donnees['image']=NULL;
        
        $this->LireXmlElement($this->fichierIni, 'Entete');
        return $this;
    }
    
    public function SauvegardeElement()
    {
        $this->EcrireXmlElement($this->fichierIni, 'Entete');
    }
  

    
}