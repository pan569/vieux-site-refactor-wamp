<?php
namespace motif\modele;

use systeme\objets\Item;

class listeFichiers  extends Item
{
    
    public $dossier;
    protected $typeFichier;
    
    public function __construct(string $dossier = null,string $typeFichier = null )
    {
        
        self::getDictionaire()->clearDefinition();
        $this->dossier = $dossier;
        $this->typeFichier = $typeFichier;
        
        
        if($this->dossier != null && $this->typeFichier != null)
            $this->lister();
            
            return $this;
    }
    
    public function lister()
    {
        
        $dirname = $_SERVER ["DOCUMENT_ROOT"].$this->dossier.'/'.$this->typeFichier.'/';
        
        str_replace( ["\\",'/'] , DIRECTORY_SEPARATOR , $dirname ); 
        
        $dir = opendir($dirname);
              
        while($file = readdir($dir))
        {
            if($file != '.' && $file != '..' && !is_dir($dirname.$file))
            {
                $extension = substr(strrchr($file, '.'), 1);//recupere l'extension                
                if ($extension == $this->typeFichier)
                {
                    $fichier =str_replace( '\\' , '/' , $this->dossier )."/{$this->typeFichier}/". $file;
                    $this->donnees[str_replace(".{$this->typeFichier}", '', $file)] = $fichier;
                    
                    //$this->addCss($href);
                }
            }
        }
        
        closedir($dir);
    }
}

