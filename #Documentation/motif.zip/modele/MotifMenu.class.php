<?php
namespace motif\modele;

use systeme\objets\Item;

class MotifMenu  extends Item
{
    
    public $fichierIni;
    
    public function __construct(string $fichierIni, string $menus)
    {
        
        self::getDictionaire()->clearDefinition();
        $this->fichierIni = $fichierIni;
                
        $this->getMenus($menus);
        
        return $this;
    }
    
    public function getMenus($menus)
    {        
        $lienMenu = new lienMenu();        
        $tab = \systeme\objets\Persistance::getInstance()->LireXmlListeElement($this->fichierIni, $menus,  $lienMenu->getCle());

        foreach ($tab as $titre)
        {
            $newlienMenu= new lienMenu($this->fichierIni, $menus,  $titre);        
            $this->donnees[$newlienMenu['titre']]=$newlienMenu;
        }        
    }
    
    
}

